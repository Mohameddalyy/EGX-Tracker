import {getState,setTimeframe} from './src/core/chart.js';
import {getOhlcv} from './src/core/data.js';
import {evaluate} from './src/connection.js';
import {writeFileSync,mkdirSync} from 'node:fs';
const original=await getState();
const out={retrieved_at:new Date().toISOString(),original};
try {
  out.metadata=await evaluate(`(()=>{const c=window.TradingViewApi._activeChartWidgetWV.value();const s=c.symbolExt();const r={};for(const k of Object.keys(s)){if(/delay|session|timezone|currency|adjust|status|exchange|name|symbol|volume|data_status/i.test(k)&&typeof s[k]!=='function')r[k]=s[k];}return r;})()`);
  out.daily_switch=await setTimeframe({timeframe:'1D'});
  out.daily=await getOhlcv({count:500,summary:false});
  out.raw_volume_check=await evaluate(`(()=>{const b=window.TradingViewApi._activeChartWidgetWV.value()._chartWidget.model().mainSeries().bars();let missing=[];for(let i=b.firstIndex();i<=b.lastIndex();i++){const v=b.valueAt(i);if(v&&(v[5]===null||v[5]===undefined||!Number.isFinite(v[5])))missing.push(v[0]);}return {count:b.size(),missing_volume_times:missing};})()`);
  const bars=out.daily.bars;
  const date=t=>new Date(t*1000).toISOString().slice(0,10);
  const seen=new Set();const issues=[];const gaps=[];
  bars.forEach((b,i)=>{if(seen.has(b.time))issues.push({date:date(b.time),issue:'duplicate'});seen.add(b.time);if(!['open','high','low','close','volume'].every(k=>Number.isFinite(b[k])))issues.push({date:date(b.time),issue:'nonfinite'});if(b.low>Math.min(b.open,b.close)||b.high<Math.max(b.open,b.close)||b.high<b.low)issues.push({date:date(b.time),issue:'ohlc_range'});if(b.volume<0)issues.push({date:date(b.time),issue:'negative_volume'});if(i&&b.time<=bars[i-1].time)issues.push({date:date(b.time),issue:'order'});if(i){for(let t=bars[i-1].time+86400;t<b.time;t+=86400){const d=new Date(t*1000).getUTCDay();if(d!==5&&d!==6)gaps.push(date(t));}}});
  out.validation={bars:bars.length,first:date(bars[0].time),last:date(bars.at(-1).time),issues,weekday_gaps_requiring_calendar_reconciliation:gaps,zero_volume_sessions:bars.filter(b=>b.volume===0).map(b=>date(b.time)),latest_bars:bars.slice(-5)};
} catch(e){out.error=e.message;} finally {out.restore=await setTimeframe({timeframe:original.resolution});}
mkdirSync('../../verification',{recursive:true});writeFileSync('../../verification/comi-tradingview.json',JSON.stringify(out,null,2));
console.log(JSON.stringify({metadata:out.metadata,validation:out.validation,raw_volume_check:out.raw_volume_check,error:out.error,restore:out.restore},null,2));process.exit(out.error?1:0);
