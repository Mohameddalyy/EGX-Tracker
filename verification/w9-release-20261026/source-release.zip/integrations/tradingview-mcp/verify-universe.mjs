import {getState,setTimeframe,setSymbol} from './src/core/chart.js';
import {getOhlcv} from './src/core/data.js';
import {evaluate} from './src/connection.js';
import {writeFileSync,mkdirSync} from 'node:fs';
const original=await getState(); const result={retrieved_at:new Date().toISOString(),original,stocks:[]};
async function ready(symbol,tf){let prev='',stable=0;for(let i=0;i<40;i++){const s=await evaluate(`(()=>{const c=window.TradingViewApi._activeChartWidgetWV.value();const m=c._chartWidget.model().mainSeries();const b=m.bars();const info=m.symbolInfo();return {symbol:c.symbol(),series:info?.ticker||info?.name,resolution:c.resolution(),count:b.size(),last:b.valueAt(b.lastIndex()),loading:typeof m.isLoading==='function'?m.isLoading():null};})()`);const bare=x=>String(x||'').split(':').at(-1).toUpperCase();const ok=(!symbol||bare(s.symbol)===bare(symbol)&&bare(s.series)===bare(symbol))&&(!tf||s.resolution===tf)&&s.count>0&&s.loading!==true;const sig=JSON.stringify(s);stable=ok&&sig===prev?stable+1:0;prev=sig;if(stable>=2)return true;await new Promise(r=>setTimeout(r,300));}return false;}
const deps={waitForChartReady:ready};
try {
 for(const ticker of ['COMI','AMOC','SWDY']) {
  const r={ticker};result.stocks.push(r);
  const sw=await setSymbol({symbol:'EGX:'+ticker,_deps:deps});const tf=await setTimeframe({timeframe:'1D',_deps:deps});
  r.state=await getState(); if(!sw.chart_ready||!tf.chart_ready||r.state.symbol.split(':').at(-1)!==ticker)throw Error('Chart not ready for '+ticker);
  r.adjustment=await evaluate(`(()=>{const c=window.TradingViewApi._activeChartWidgetWV.value();const s=c._chartWidget.model().mainSeries();let r={symbolExt:c.symbolExt()};try{r.symbolInfo=s.symbolInfo();}catch(e){r.symbolInfoError=e.message;}try{const p=s.properties().childs();r.properties={};for(const k of Object.keys(p)){if(/adjust|dividend|split|session|currency/i.test(k)){try{r.properties[k]=p[k].value();}catch{}}}}catch(e){r.propertyError=e.message;}r.adjustmentMethods=[];for(let p=s;p;p=Object.getPrototypeOf(p)){for(const k of Object.getOwnPropertyNames(p))if(/adjust|dividend|split/i.test(k))r.adjustmentMethods.push(k);}return r;})()`);
  r.history=await getOhlcv({count:500,summary:false});
  r.missingRawVolume=await evaluate(`(()=>{const b=window.TradingViewApi._activeChartWidgetWV.value()._chartWidget.model().mainSeries().bars();let r=[];for(let i=b.firstIndex();i<=b.lastIndex();i++){const v=b.valueAt(i);if(v&&!Number.isFinite(v[5]))r.push(v[0]);}return r;})()`);
  const bars=r.history.bars; const date=t=>new Date(t*1000).toISOString().slice(0,10);let issues=[],gaps=[];
  bars.forEach((b,i)=>{if(!['open','high','low','close','volume'].every(k=>Number.isFinite(b[k])))issues.push({date:date(b.time),issue:'nonfinite'});if(b.low>Math.min(b.open,b.close)||b.high<Math.max(b.open,b.close)||b.low>b.high||b.volume<0)issues.push({date:date(b.time),issue:'range_or_volume'});if(i&&b.time<=bars[i-1].time)issues.push({date:date(b.time),issue:'timestamp_order'});if(i){let start=new Date(date(bars[i-1].time)+'T00:00:00Z').getTime()+86400000;const end=new Date(date(b.time)+'T00:00:00Z').getTime();for(let t=start;t<end;t+=86400000){const d=new Date(t);if(![5,6].includes(d.getUTCDay()))gaps.push(d.toISOString().slice(0,10));}}});
  r.validation={count:bars.length,first:date(bars[0].time),last:date(bars.at(-1).time),issues,gaps,zeroVolume:bars.filter(b=>b.volume===0).length,latest:bars.slice(-3)};
  console.log(JSON.stringify({ticker,validation:r.validation,adjustment:r.adjustment,missingRawVolume:r.missingRawVolume}));
 }
}catch(e){result.error=e.message;console.log(JSON.stringify({error:e.message}));}
finally{result.restoreSymbol=await setSymbol({symbol:original.symbol,_deps:deps});result.restoreTimeframe=await setTimeframe({timeframe:original.resolution,_deps:deps});mkdirSync('../../verification',{recursive:true});writeFileSync('../../verification/egx-three-stock-verification.json',JSON.stringify(result,null,2));console.log(JSON.stringify({restored:await getState()}));}
process.exit(result.error?1:0);
