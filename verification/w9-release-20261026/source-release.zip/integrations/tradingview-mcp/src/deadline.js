export async function withDeadline(promise, label, milliseconds=10000){
 let timer;
 try{return await Promise.race([promise,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error(`TradingView ${label} timed out after ${milliseconds}ms`)),milliseconds);})]);}
 finally{clearTimeout(timer);}
}
