# AJWA preliminary primary-source research

Completed 2026-10-11T08:19:02Z. No candidate/context ID assigned. Research notes only; no queue, chart, watchlist, plan, order or fill changes. Accesses occurred this session; individual earlier fetch times were not logged.

## Identity and accessible primary evidence

[TradingView AJWA](https://www.tradingview.com/symbols/EGX-AJWA/) directly opened: Ajwa for Food Industries Co. Egypt, EGX, ISIN EGS30211C014, issuer website ajwa-egypt.com. No market quote from this crawled public page is treated as immutable/current-final trading evidence. Financial fields for revenue, net income, EPS and PE were missing. Community ideas are not company evidence.

[Issuer financial archive](https://ajwa-egypt.com/investor-relation/القوائم-الماليه/) directly opened: annual table ends2024; standalone interim table reaches third-quarter2025; 2025 consolidated row blank. Its latest standalone link opens [September2025 financials and limited review](https://ajwa-egypt.com/wp-content/uploads/2026/03/القوائم-المالية-المستقلة-المنتهية-فى-30-سبتمبر-2025-وتقرير-الفحص-المحدود-عليها.pdf),35 scanned pages with no extracted text. Filename/upload path suggests March2026 upload, not independently established publication day. Underlying figures/opinion have NOT been verified. No2026 financials exposed in this bounded archive view; this does not establish they do not exist elsewhere.

[Issuer annual reports](https://ajwa-egypt.com/investor-relation/التقارير-السنويه/) ends2017. [Issuer ownership](https://ajwa-egypt.com/investor-relation/هيكل-المساهمين/) displays Mohamed bin Issa bin Jaber Al Jaber61.619%, with only2017 disclosure attachments and no reliable current as-of date for the table. This is **historical/undated**, insufficient to establish current majority ownership. Do not adopt its share count or float as current.

[Issuer news](https://ajwa-egypt.com/investor-relation/الأخبار/) and [board/assembly archive](https://ajwa-egypt.com/investor-relation/قرارات-مجلس-الإداره-و-الجمعيات/) directly opened; visible latest items are September2017. These cannot clear current news/actions.

## Current regulator evidence

[FRA settlement announcement](https://fra.gov.eg/en/fra_news/في-إطار-حماية-حقوق-المتعاملين-الرقاب/) directly opened. Title dated22 July2026; last modified26 July2026. FRA says full EGP62,292,683 settlement funds were deposited/cleared with MCDR for5,719 eligible investors who purchased AJWA during4–25 October2009 or heirs. Disbursements were initiated after required procedures. The article links this to enforcement/grievance decisions. This is an eligible historical-investor settlement, **not a dividend or automatic entitlement for an October2026 buyer**. It does not prove all individual payouts completed or resolve every company dispute/accounting issue.

## Unverified discovery leads — NOT facts cleared by primary access

A secondary disclosure index was used only to find primary EGX URLs. [EGX NewsID295611](https://www.egx.com.eg/ar/NewsDetails.aspx?NewsID=295611), reportedly6 October2026 ownership/board form, failed direct access with502. [EGX NewsID290627](https://www.egx.com.eg/ar/NewsDetails.aspx?NewsID=290627), reportedly30 June2026 standalone annual2025 results, also failed502. Neither contents nor primary publication date verified. No mirror PDF was substituted.

Search results additionally suggest September8 and23 listing-committee decisions concerning delayed filings; **not independently confirmed**. These are priority leads for a fresh EGX UI check, including any later cure. Do not present a penalty amount, delay period, earnings figure or cure as established. Excluded-source snippets appearing incidentally in searches were not used as evidence.

The in-app browser selected earlier was unavailable when opening the EGX beta News Center, so no current full EGX sweep is claimed.

## Preliminary implication / required completion

Current financials, consolidated group performance, cash flow, leverage, audit/review opinion, current owners, subsequent transactions, dividends/capital changes and October disclosures remain unverified. Confirm listing-status/delayed-filing leads and subsequent cures from dated EGX evidence. Obtain current ownership form and financial attachments. Until then financial/ownership/news/action checks remain incomplete; a technical score cannot supply the missing evidence. This is an uncompleted research candidate, not a formally excluded stock or approved plan.
