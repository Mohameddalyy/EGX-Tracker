# Preliminary AMOC / AIH primary evidence

Access date 11 October 2026; note completed 2026-10-11T08:10:04Z (individual fetch timestamps were not separately logged). Parent-supplied preliminary screen hypotheses only; full import ongoing. No queue claims, risk plans, watchlist edits, TradingView chart operations or trades. Source policy sources-2026-10-09 observed. Legacy AMOC receives no preferential approval.

## AMOC

Issuer archive https://www.amoceg.com/en/investor/financial-report/financial-statement provides consolidated June 2026 statements. Downloaded and visually inspected pages 1–5, 7–9, 35–38 of https://www.amoceg.com/reports/investor/financialStatement/93-6a8425a18c8e71787045281.pdf (local tmp/pdfs/amoc-consolidated-2026-06.pdf). Publication date not shown; board approval 13 August 2026 (p38). Figures EGP, not thousands. Cover describes limited review; the actual review opinion was not located in inspected pages, so do not call audited/clean opinion.

Financial facts: January–December fiscal year starts in 2026; 2025 transition was July–December (p9). June2026 is interim, not an annual fiscal year. Revenue26,223,032,454; attributable profit1,881,950,266; operating cash flow1,411,555,283 versus1,520,889,681 comparative. Net receivables2,035,100,729 versus573,136,185 at December2025. Cash3,018,394,920; current liabilities5,153,568,734. Cash conversion and receivable growth challenge the profit headline. Credit/currency/liquidity risks and unresolved tax disputes remain; no calibrated loss probability or fair value estimated.

Ownership: https://www.amoceg.com/en/investor/corporate-governance/disclosures/disclosure-reports links March2026 as newest listed report. Downloaded https://www.amoceg.com/reports/investor/disclosure/43-6a55dbe63a52a1784011750.pdf (tmp/pdfs/amoc-disclosure-2026-03.pdf), pages1–3 inspected. March31 percentages: Alexandria Petroleum20.774%, Al Ahly Capital15.033%, Misr Insurance5.478%, governmental social insurance5.156%, other social insurance5%. Libya for Investment fell5.536% to1.122%; Misr Capital previously3%, current dash. This verifies named historical major owners, not October beneficial control. No individual majority owner established. Issuer undated HTML table is less current/reliable than dated filing.

Corporate action: https://www.amoceg.com/reports/investor/generalAssembly/35-69ca3d737e15f1774861683.pdf (tmp/pdfs/amoc-dividend-2026-03.pdf) is signed Form232 linked from issuer March26 assembly. Coupon22 total0.40EGP/share for July–December2025; record date19April2026; first0.20 paid/scheduled22April; second0.20 scheduled15October2026. October buyers do not gain April-record entitlement. Do not book October15 dividend for a new pilot position merely because it is held on payment date. This source states schedule, not confirmation of actual payment.

Catalyst source https://www.amoceg.com/en/media-center/news/186, published31July2026: issuer signed CHP term sheet with Intro Utilities,16MW scalable30MW, BOOT, investment up toUSD50m; projected annual AMOC savingsEGP49m. EGP174m total includesEGP125m government benefit and is not all AMOC earnings. No commissioning/completion verified. Treat projections as issuer expectations and financing/execution obligations as an evidence gap.

Remaining before all gates: October exchange news/action sweep, June/September ownership update if published, actual limited-review opinion, full material notes/related parties and contingent liabilities, immutable final-bar technical/liquidity context and valid priced risk geometry. Financial archive makes research more feasible than other leads, but all six checks are not yet complete.

## AIH

Identity verified through https://www.tradingview.com/symbols/EGX-AIH/: Arabia Investments Holding SAE, ISIN EGS21351C019, website https://aih-group.com/ . AIHC appears in exchange/secondary naming; reconcile by ISIN rather than ticker string alone. Do not confuse ASX Advanced Innergy Holdings or Chinese aesthetic-medical AIH.

Issuer website failed via web timeout and direct public HTTP request returned500 Server Error. Search of indexed issuer and official EGX domains found no readable financial statement. No primary ownership or current corporate-action document obtained. Secondary search snippets point to losses and 2026 results, but numbers were not adopted as verified evidence. TradingView financial overview displays negative earnings without enough report-period/reconciliation detail to replace primary statements. User-submitted TradingView ideas are not financial evidence.

Disposition: insufficient evidence/defer; cannot complete financial, ownership and news/action gates from current access. Need issuer/EGX June2026 and audited2025 consolidated statements, named owners and related-party holdings, recent Article29 documents, corporate actions and filing timeliness. No finding of wrongdoing inferred from website unavailability, and no momentum approval from score4 alone.

## Tool/access record

Web search/open succeeded for AMOC issuer and TradingView identity. Web PDF text extraction empty; shell public downloads succeeded after ordinary network sandbox escalation, then bundled Poppler rendering/view_image enabled direct inspection. AIH website500 persisted on direct request. In-app browser unavailable in this follow-up (both iab and prior selected browser2); therefore no claim of fresh EGX UI news sweep. Earlier ACGC/ADRI browser findings remain separately dated in their note.
