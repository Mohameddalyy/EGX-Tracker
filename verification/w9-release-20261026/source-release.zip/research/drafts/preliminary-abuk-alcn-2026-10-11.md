# Preliminary ABUK / ALCN evidence — 11 October 2026

Research notes only; no queue IDs, pipeline reports, clearance, plans, orders or watchlist changes. Prepared while the parent imports the full universe. No TradingView charts manipulated. Completion timestamp: 2026-10-11T08:16:54Z; individual earlier fetch timestamps were not logged. Sources below were accessed during this session. Search coverage is bounded, not an assertion that no newer filing exists. Only issuer, acquirer and exchange sources support facts below.

## ABUK

Primary [financial archive](https://abuqir.net/investor-relations/financial-statements/) led to [June 2026 statements](https://abuqir.net/wp-content/uploads/2026/08/Financial-statements-30-6-2026.pdf). Download saved as `tmp/pdfs/abuk-financial-2026-06.pdf`; web text read and pages 4–6 visually inspected. Publication day not independently established; reviewer dated 12 August 2026.

Statements are individual, with equity-method/restated comparatives. H1 revenue EGP23.525bn versus12.667bn; net profit10.012bn versus4.568bn; CFO8.229bn versus4.498bn. Assets36.869bn, equity29.462bn, cash18.460bn, liabilities7.407bn. KPMG gives an unqualified **limited-review** conclusion, not an audit opinion; comparative interim figures were not reviewed. Q2 FX loss1.740bn and H1 impairment/ECL386m are material contrary evidence. June ownership: Alpha Oryx21.52%, Saudi Egyptian Investment20.40%, EGPC19.11%, Holding Chemical7.36%, Nasser Social Bank5.90%, employee union5.15%, others20.56%. No individual majority established. Gas-cost formula and issuer-reported policy changes remain earnings risks; current legal status needs regulator evidence. Figures are EGP, not thousands.

Issuer [23 September coated-urea agreement](https://abuqir.net/abu-qir-fertilizers-signs-agreement-with-british-company-bioftech-uk-ltd-to-produce-coated-urea-using-advanced-technology/) is a prospective catalyst. No quantified realised earnings or completed implementation was verified. Date came from issuer archive; page accessed.

The [June ownership-disclosure page](https://abuqir.net/disclosure-report/disclosure-report-on-bod-shareholders-composition-30-6-2026/) produced no usable attached document; ownership above instead comes from financial note18. Dynamic zero counters on the IR landing page were ignored.

Gaps: latest October EGX disclosure/action sweep, dividend record/ex/payment dates, any post-June ownership changes, newer results or material events, current price/volume/weekly trend and immutable queue context. Financial and dated ownership evidence are feasible; the complete news/action gate is not yet satisfied. Do not infer dividend entitlement or an absence of actions.

## ALCN

Issuer [financial archive](https://alexcont.com/financial-statement/) led to [June 2026 statements](https://alexcont.com/wp-content/uploads/2026/08/Financial-Statement-Second-Quarter-2026.pdf). Saved as `tmp/pdfs/alcn-financial-2026-06.pdf`; pages1–5 and7 visually inspected. Actual Grant Thornton limited-review report dated16 August2026 is **qualified**. Renewable port land/yards/berths licences were not accounted for under EAS49. Reviewer quantifies omitted right-of-use assets EGP2.884bn and lease liabilities3.461bn; compliance would reduce interim profit185m and retained earnings391m. Cover language must not be mistaken for a clean audit. Comparatives were unreviewed/unaudited following fiscal-year change. Balance sheet reports assets8.802bn, equity8.103bn, liabilities699m and cash3.991bn before missing leases; apparent low leverage is misleading. Source face amounts are EGP thousands. No subsequent cure verified.

Issuer [H1 earnings release](https://alexcont.com/wp-content/uploads/2026/08/Earnings-Releases-%D9%8DSecond-2026-Quarter-1.pdf), August-path publication (exact day unverified), labels figures unaudited: throughput+8%, revenue4.576bn(+3%), net3.798bn(+18%), CFO2.647bn versus2.853bn(-7%). Its expectation about the review does not override the actual qualification. Web PDF text accessed.

[June ownership filing](https://alexcont.com/wp-content/uploads/2026/07/Shareholder-Second-Quarter.pdf), July-path publication (exact day unverified), saved as `tmp/pdfs/alcn-ownership-2026-06.pdf`; all four pages visually inspected. June30 stakes: Holding Maritime/Land Transport36.28543%, Alexandria Port Authority7.63072%, Alpha Oryx32%, Black Caspian19.328748%. Black Caspian is wholly owned by AD Ports; the filing identifies Abu Dhabi Developmental Holding as75.42% owner of AD Ports. No individual majority then. Regulatory free float12.95002% uses a different definition from the residual of named holders; do not substitute the residual for free float.

[ADX-hosted acquirer release, 11 June2026](https://apigateway.adx.ae/adx/cdn/1.0/content/download/4994517), web PDF accessed: proposed offer EGP27.47/share for Alpha Oryx's32% plus up to4.3% public shares; regulator approvals remained conditions. This supersedes older22.99 offer references.

[Acquirer update, 14 August2026](https://www.adportsgroup.com/en/news-and-media/2026/08/14/ad-ports-group-reports-q2-2026-net-profit-of-aed-836-million-demonstrating-strong-performance), directly opened and read: ALCN mandatory tender offer was now expected to close in **Q4 2026**. This is a forward-looking expectation, not completion evidence. No later completion, clearance or final settlement was verified.

Gaps/blockers: accounting qualification and any cure; final FRA/EGX takeover status, terms, timetable and ownership; current dividends/actions; latest October disclosure sweep; current immutable technical context. Need a valuation incorporating omitted leases and takeover scenarios before any entry case. A favourable screen cannot clear these gaps. These notes identify contrary evidence; they are not a final Avoid/Wait/Watch decision.

## Access limits

Issuer HTML/PDF and primary acquirer/ADX pages were accessible. Scanned ALCN PDFs were downloaded and rendered with Poppler for visual reading; text-only extraction was insufficient. The in-app browser became unavailable after earlier ACGC/ADRI research, so no fresh full EGX News Center sweep is claimed here. No excluded-source values were adopted. Retain unreviewed names separately from formal exclusions.
