# Preliminary primary-source research: ACGC and ADRI

Accessed 2026-10-11, approximately 08:00–08:02 UTC. Preliminary leads supplied by parent during an incomplete full-universe history import; no candidate IDs, formal report, risk plan, orders, fills or watchlist changes. No TradingView chart interaction or refresh performed. Source policy sources-2026-10-09 applies. No excluded-source numbers adopted.

## ACGC — material reporting gap; defer pending evidence

Direct EGX News Center browser search for ACGC returned two disclosure records in the interface's current date scope. Opened both detail modals:

- Disclosure 295233, published 28 September 2026 at 3:08 PM: company release concerning delayed submission of consolidated financial statements for periods ended 31 December 2025 and 31 March 2026. Attachment: https://egx.com.eg/downloads/Bulletins/344784_1.pdf . The attachment itself has not been read. The modal verifies the delay; it does not provide a cure or explain the reasons in detail.
- Disclosure 295056, published 23 September 2026 at 12:04 PM: Listing Committee meeting dated 22 September imposed EGP40,000 penalty for Article 47 violation relating to those consolidated periods, referencing Article 64 of executive regulations. No attachment was shown.
- Source UI: https://beta.egx.com.eg/en/media-center?tab=disclosure . Search text ACGC, result details inspected through native browser accessibility tree. No subsequently dated cure appeared among these two displayed records; this is bounded search evidence, not proof of absence from all exchange records.

Issuer https://www.arabcot.com/stock_information.aspx?Lid=5 embeds its MIST-hosted investor-relations portal: https://www.mistnews.com/allinone_ir/login.aspx?ID=1011050313&lg=ar . The opened portal indexes standalone 2026 and consolidated annual 2025 financial statements, June 2026 ownership disclosure and an August 2026 bonus-share event. Download controls were not usable as document links in web extraction, so the underlying statements, current ownership and corporate action have not been independently verified. No embedded price or valuation figures are used.

Main issuer financial page https://www.arabcot.com/annual_reports.aspx returned only navigation. Main site includes old material: bonus event detail https://www.arabcot.com/economic_agenda.aspx?TID=1 is explicitly March 2010, and overview shareholder structure is labelled February 2014. Neither supports current owners or actions.

Outstanding: subsequent cure, consolidated cash flow/debt/recurring earnings, audit opinion, current beneficial owners, precise latest corporate-action adjustment and current immutable TradingView price/volume structure. Reporting delay is a concrete governance/evidence risk; current valuation cannot responsibly be established. No unsupported claim that fundamentals deteriorated.

## ADRI — primary documents unavailable; incomplete evidence

TradingView issuer identity page https://www.tradingview.com/symbols/EGX-ADRI/ identifies Arab Development & Real Estate Investment, ISIN EGS65AN1C018, real estate development, and issuer website arab-egypt.com. Web page prices were not treated as current market observations.

https://arab-egypt.com/ opened as a Coming Soon / signup placeholder. No financial statements, owner table or operational update available there.

Direct EGX News Center browser search ADRI returned two current-scope disclosure records. Opened both:

- Disclosure 295555, published 5 October 2026 at 2:56 PM, Article 29 disclosure-form release, SMEs Market. Attachment https://egx.com.eg/downloads/Bulletins/345035_1.pdf . Web open failed as inaccessible.
- Disclosure 295504, published 4 October 2026 at 11:27 AM, same Article 29 disclosure-form category. Attachment https://egx.com.eg/downloads/Bulletins/344974_1.pdf . Underlying document not yet read.

These headlines alone do not establish a capital increase, dividend, ownership change or any particular corporate action. Outstanding: latest interim/audited financial statements, collections/deliveries, project cash flow, leverage and related parties, current named owners/control, contents of both Article 29 filings, and current immutable TradingView chart/liquidity evidence. Advisory disposition is defer/insufficient evidence, not a finding of misconduct or an execution recommendation.

## Access evidence and limitations

Web read of https://www.egx.com.eg failed 502; beta EGX homepage and interactive News Center succeeded. The browser source exposes company codes and dated disclosure details but link URLs do not identify the modal itself; retain disclosure IDs and publication times above. Other search-engine secondary snippets are discovery leads only and do not substantiate this note. Search exclusions are distinct from companies not yet reviewed. Full universe research remains ongoing under the parent task.
