# EGX analytical development review

Prepared 18 October 2026, Africa/Cairo. This is a researched design review, not a new stock recommendation, strategy validation or policy amendment. The user clarified that there is no token budget: efficiency must preserve analytical quality and scope.

## Assessment of the present system

The tracker has useful foundations: sourced company research, immutable contexts and forecasts, an independent final review, reproducible entry/stop/target calculations, explicit missing evidence, a separate paper ledger and an execution-path acceptance test. These support accountable decisions. They do not establish an ability to select profitable opportunities.

The analytical implementation is less developed than its operational controls:

1. `app/scout.mjs` awards seven equally weighted heuristic points. Five arise from price/volume: price above SMA50, positive six-month momentum excluding the latest month, upper momentum percentile, three-month relative performance versus EGX30, and relative volume. Two concern positive P/E and ROE relative to industry peers. These are research-priority features, not independent forecasts or fitted expected returns. The screen can pass a stock without verified financial data, correctly leaving verification to the analyst, but the resulting rank is predominantly technical.
2. `app/trade-plans.mjs` supports pullback and breakout geometry using fixed ATR buffers, requires an existing overhead resistance for targets, and enforces a fixed cost-adjusted T1 reward/risk hurdle. It does not model probability of reaching a target, time to target, alternative exit policies or a company-value distribution. An absent overhead pivot produces Wait even during price discovery. The earlier audit identified ADRI, ARAB and TWSA as historical examples of that limitation, not current approvals.
3. `app/research-card.mjs` provides useful sector prompts and ratio comparisons. Most financial analysis remains narrative. There is no reusable, reconciled multi-period operating forecast and valuation engine comparable to a financial analyst's spreadsheet model.
4. `app/paper-performance.mjs` explicitly leaves portfolio historical VaR/CVaR, risk-adjusted statistical inference, walk-forward validation and challenger comparison unimplemented. Sizing and exposure caps exist, but they are not a covariance or scenario-risk model.
5. Decisions and forward observations are stored, including Wait/Avoid. There is no implemented case-retrieval and independently validated strategy-learning loop. A favourable subsequent return is not evidence that the original reasoning was correct.
6. Evidence acquisition is a major research bottleneck. The historical 15 October audit found unresolved corporate-action clearance in all 16 current Wait reports, news in 15, ownership in 13 and financials in 11. Later saved reports recover some gaps. These are historical completeness counts, not current company assessments. The capability snapshot records only 57/296 usable P/E observations and 59/296 ROE observations at its verification date; they cannot support an illusion of comprehensive fundamental coverage.

Local evidence: `verification/wait-decision-audit-20261015.md`, `verification/failed-week-recovery-20261018.md`, `research/tradingview-capabilities.json`, the source modules above and the immutable failed-week report. The experiment's zero fills cannot demonstrate or disprove a trading edge.

## Comparisons with public systems and research

These comparisons concern published capabilities and design. No external system was run against our tracker on identical EGX data. Reported returns from different markets, periods, costs and information sets do not establish that one system is superior for this user. Public institutional material does not expose proprietary investment-bank trading models.

| Reference | Documented capability | Relevant gap and adaptation for EGX |
| --- | --- | --- |
| TradingAgents | Specialized financial, news, sentiment and technical analysts; explicit bullish/bearish research; risk and portfolio review. Its maintainers describe results as sensitive to the model, data and experimental settings. | Our final reviewer already challenges reports, but a consistent evidence-backed dispute is not enforced. Add a bounded bull/bear challenge to selected theses and require the final decision to resolve the most consequential disagreement. Keep the present three-agent separation rather than copy every role. |
| FinRobot | Separates deterministic financial calculation from LLM interpretation, including valuation methods and tracked provenance. | Extend our deterministic price/risk calculations into source-linked company models. The language model interprets assumptions and challenges them; arithmetic and sensitivity tables run in code. |
| Microsoft Qlib | Integrates data, forecasting, portfolio construction and backtesting; supports point-in-time data and model rolling. Its strategy documentation evaluates excess returns after trading costs. | Build a reproducible EGX feature/label dataset, simple quantitative baselines and an untouched forward comparison. Adapting these concepts does not require installing the framework or adopting its market datasets. |
| FinMem | Researches memory retrieval across layers and the use of retained information in trading decisions. | Retrieve earlier relevant company events, prior objections and comparable setup outcomes, with source dates and regime labels. Preserve failed examples alongside successful ones; do not turn memory into uncontrolled rule changes. |
| J.P. Morgan Asset Management's published research process | Emphasizes company quality, risk assessment, cash-flow forecasting and comparable research across industries. | Produce an operating thesis and quantified scenarios, rather than simply collecting ratios and indicator labels. |
| AQR factor research | Studies value/momentum together and separately investigates implementation costs in momentum portfolios. | Test distinct economic signals and their combination with EGX-specific costs/liquidity. These publications supply hypotheses, not EGX coefficients or proof of transferability. |

Sources: [TradingAgents](https://github.com/TauricResearch/TradingAgents), [FinRobot](https://github.com/AI4Finance-Foundation/FinRobot), [Qlib](https://github.com/microsoft/qlib), [Qlib portfolio/backtest documentation](https://qlib.readthedocs.io/en/latest/component/strategy.html), [FinMem paper](https://arxiv.org/abs/2311.13743), [J.P. Morgan research process](https://am.jpmorgan.com/us/en/asset-management/institutional/media/global-equities-research-capabilities/), [AQR value and momentum](https://www.aqr.com/Insights/Research/Journal-Article/Value-and-Momentum-Everywhere), [AQR momentum implementation](https://www.aqr.com/insights/research/working-paper/implementing-momentum-what-have-we-learned).

## Improvements to analytical judgement

### 1. A structured, point-in-time company model

For each company, retain statement period, publication time, first-known time, source document/page, currency, scale, consolidated/standalone scope, accounting restatements and extraction/reconciliation status. Store several comparable periods instead of relying on a latest-ratio snapshot. Check statement arithmetic, share-count continuity and corporate-action effects. Arabic/English documents need entity and numeric-unit reconciliation, including scanned documents.

Convert this into explicit business drivers and bear/base/bull scenarios. A valuation sensitivity is not a calibrated forecast probability; do not invent scenario weights. Financial fair value, broker consensus and a short-horizon trading target must remain distinct objects with distinct dates and horizons.

Sector modules should start with banks, property and industrial/consumer businesses. Banks need an equity-based valuation linked to sustainable ROE, cost of equity, capital and credit quality; generic corporate cash-flow/debt ratios are unsuitable substitutes. Property needs collections, deliveries, costs, funding and project-value sensitivities. Industrials need volume, margins, working capital, cash conversion and FX/input-cost exposure. Start with the sectors for which we can actually reconcile inputs. Damodaran's financial-services valuation material supports the bank-specific distinction. [NYU Stern value drivers](https://pages.stern.nyu.edu/adamodar/New_Home_Page/littlebook/bankvaluedriver.htm), [financial-services valuation paper](https://pages.stern.nyu.edu/~adamodar/pdfiles/papers/finfirm09.pdf).

Acceptance: an independent reviewer reproduces every model number from saved inputs; null inputs cannot quietly become zero; assumptions have dated justification; cash-flow and share-count contradictions are surfaced before a target is approved.

### 2. Market and sector context, with coverage attached

Compute market trend, breadth, volatility, turnover, sector-relative performance and stock-relative performance from aligned confirmed observations. Show the usable universe and missingness for every aggregate. A top percentile among ten usable companies is not a full-EGX percentile. Separate broad-market movement from sector strength and company-specific performance.

Add dated Egypt macro inputs and explicit transmission hypotheses: rate changes, funding costs, inflation, FX and energy/input costs can affect different firms differently. A rate cut is not automatically bullish for every bank, and a weaker currency is not automatically beneficial for every exporter. Use issuer-specific revenue, debt and cost currency exposures. CBE releases should be an authoritative input; no current macro number was verified for this review because direct access to its outlook page was rejected.

These are proposed explanatory features. Whether a regime gate improves outcomes must be tested, rather than assumed from a persuasive economic story. AQR's factor research motivates studying distinct value and momentum information, not imposing its foreign-market results on EGX.

Acceptance: state variables are reproducible, fully dated and accompanied by coverage; the same model is evaluated with and without context to measure its incremental contribution.

### 3. Catalysts and changes in expectations

Turn news into an event ledger: issuer, original public time, effective date, first local access, event type, affected business driver, anticipated economic size, evidence, prior expectations if available and what the price had already done before the decision. Deduplicate syndicated coverage of the same event. A positive headline repeated across websites is one event, not several independent confirmations.

Ask what is changing and why it might not already be reflected in the price. Where consensus is absent, record that uncertainty rather than invent an earnings surprise. A stock's popularity or high trading volume does not identify informed institutional buying. Social sentiment is secondary to dated primary evidence for this market.

Acceptance: every catalyst claim has a falsifiable link to earnings, cash flow, balance-sheet risk or supply/demand; event timing can be replayed without including future disclosures.

### 4. Separate the strategy families and their horizons

Research distinct setup hypotheses: trend pullback, breakout/retest and catalyst/earnings revision. A medium-term value/catalyst thesis may merit continued research without being a swing entry today. Each family needs its own entry, invalidation, holding-period/time-stop policy, liquidity assumptions and empirical evaluation. Avoid optimizing a large menu against the same short sample.

The current resistance-based target method is useful for its defined setup. For a versioned price-discovery challenger, compare alternatives such as a volatility-based trailing exit or a precommitted time/trend exit. Those are exit policies, not measured resistance. Any numerical target must disclose its derivation; a longer-term fundamental valuation cannot be relabelled a near-term technical target. Do not extend targets merely to make reward/risk pass.

TradingView Technical Ratings already aggregate 26 indicator constituents. Combining that label with RSI, moving averages and MACD can repeat substantially related information. Retain only features with a demonstrated incremental purpose rather than treating confluence as independent votes. [TradingView methodology](https://www.tradingview.com/support/solutions/43000614331-technical-ratings/).

Acceptance: each setup has a frozen specification and separate forward scorecard, including adverse excursion, favourable excursion, time in trade, gap loss, fillability and net payoff distribution. Failed entries and unchanged Wait decisions remain visible.

### 5. Estimate opportunity quality rather than count indicator agreement

A 2:1 payoff ratio does not establish positive expectancy. In a simplified two-outcome model with net win W and net loss L, expectancy is pW − (1−p)L; a net W/L of 2 breaks even at p=1/3. Real outcomes include unfilled entries, time exits and gaps, so their full empirical distribution matters. If costs are already in W and L, do not subtract them twice.

Use simple code-only factor ranks and, after data readiness, a modest statistical challenger before complex ML. Estimate horizon-specific benchmark-relative returns and downside with sample counts and uncertainty intervals. If there is inadequate comparable history, mark expectancy uncalibrated. An LLM confidence percentage is not a substitute for estimation.

Track separately: research completeness, source reliability, strength of the economic explanation, statistical support and portfolio suitability. Complete evidence can still support a poor trade. Missing evidence does not prove a bad business.

Acceptance: forecasts beat a predeclared simple baseline on untouched observations after realistic costs and show stability across sectors/periods; they are evaluated with turnover, concentration and data coverage rather than headline hit rate alone.

### 6. Portfolio choice and executable risk

Compare candidates with one another, not only against the same standalone threshold. Use sector/factor/FX exposures, correlation uncertainty, available cash, existing stop scenarios, expected holding overlap and stressed liquidity. Assess whether an additional bank or property company contributes much independent exposure.

Implement portfolio historical scenarios, VaR/CVaR and gap/illiquidity stresses only when aligned histories are adequate. Stops cap planned sizing risk, not the realised loss under all paths. With a small portfolio, fixed EGP10 round-trip fees and realistic spread/participation assumptions can materially change candidate economics. A cash floor is a constraint, not a reason to describe all unallocated capital as optimal. Never force a position to avoid cash.

For swing trading on delayed data, the agent should generate durable conditional plans and recheck executable prices. A delayed quote can support analysis, but its observed past price is not an available fill. The present five-minute simulated entry window should be evaluated against the user's swing mandate in a future version, including how subsequent captures actually provide those minutes; it is not inherently invalid merely because the feed is delayed.

Acceptance: portfolio-level scenario loss and shared budget are recomputed before each proposed entry, and delayed evidence never creates retrospective execution.

### 7. Evidence-backed challenge and controlled learning

For each thesis, require the strongest supporting evidence, the strongest contrary evidence, the alternative explanation, what is already priced in, the observation that would overturn the thesis, and why the selected opportunity is better than another eligible candidate. The final reviewer resolves material disagreements with evidence and calculations; majority voting across similar prompts is not independent validation.

Retrieve past cases by company, sector, catalyst, regime, setup and the original evidence available then. Review both false positives and false negatives: approved trades that failed, avoided losses, candidates that rose after a Wait, and promising stocks never researched or never filled. A stock rising afterwards is a diagnostic lead, not proof that buying it was sensible at the earlier time.

Learn through written error taxonomies and proposed versioned changes, tested on untouched data. Do not rewrite forecasts, automatically relax risk/evidence checks or retrain weights from a few outcomes. FinMem is an architectural reference for retrieval, not evidence that autonomous self-modification is safe or profitable for EGX.

Acceptance: one reviewer can distinguish data, extraction, valuation, thesis, timing, portfolio and execution failures from immutable evidence; a change's benefit is measured separately from an attractive retrospective explanation.

## Fair comparison of models

Two comparisons are needed: the investment strategy and the language model supporting research.

For strategy: retain the current frozen model as champion, add a transparent code-only baseline and one clearly specified hybrid challenger. Use the same point-in-time universe, dates, information cutoff, fees, execution assumptions and eligible capital. Compare buy-and-hold/benchmark context and available cash consistently. Use walk-forward or prospective evaluation; do not train and select variants on the final test period. Overlapping 5/20/60-session labels require leakage controls. Log every attempted variant to avoid promoting the luckiest backtest. Microsoft's Qlib offers a useful design reference for reproducible quant experiments; our EGX dataset and forward protocol still need to be built.

For language models: evaluate candidates on the same frozen EGX dossiers, prompts, tool permissions and task requirements. Blind-score source fidelity, statement extraction, numerical accuracy, recognition of contradictions, sector reasoning, useful counterarguments, decision stability and the actual improvement over the code-only baseline. Track latency and resource use alongside quality; no token cap or shortened mandatory research is imposed. Historical LLM tests can still suffer memorized future knowledge, so prospective performance remains essential. This review does not establish that any GPT, Claude, Gemini or other backbone is the best EGX analyst.

## Efficiency requirement

No token budget is introduced. Coverage, evidence standards and depth are requirements.

- Compute full-universe numerical features and shared market/sector statistics once for each relevant observation set.
- Store original documents plus versioned extracted facts, so every needed source can be reopened. Reuse verified extraction when the underlying document has not changed.
- Refresh news/actions and other perishable evidence on their appropriate cadence. Unchanged scores do not imply unchanged news or company circumstances.
- Maintain company dossiers and an explicit backlog for the full catalog, including never-reviewed stocks. Ranking sets review order; it must not permanently restrict research to five familiar companies. The existing maximum of five unfinished handoffs is a concurrency control, not an analytical universe.
- Retrieve exactly the evidence needed for the question, and expand to complete statements/notes whenever reconciliation, a contradiction or a new thesis requires it. A compact agent handoff is an index to evidence, not a replacement for it.
- Parallel independent analysis can share the same immutable facts; chart collectors remain sequential. Repeated debates without new evidence do not create analytical depth.

## Recommended build sequence

| Order | Deliverable | Proof required |
| --- | --- | --- |
| 1 | Structured analytical dossier and statement/event extraction with publication dates and reconciliations | Reproduce selected bank/property/industrial cases from primary sources; numerical outputs are code-calculated and provenance-linked. |
| 2 | Full-universe market/sector context and separate quality, valuation, momentum and liquidity views | Show usable coverage; demonstrate that rankings do not hide missing inputs or count related indicators as independent evidence. |
| 3 | Strategy-specific thesis, scenario and exit models | Produce a complete conditional research decision explaining why this stock, why now, why this price, the alternative, invalidation and the expected holding horizon. |
| 4 | Portfolio scenarios and prospective champion/challenger comparison | Evaluate expected payoff, costs, drawdown and correlation/liquidity under common conditions; no automatic promotion. |
| 5 | Independent error review and relevant-case retrieval | Demonstrate that a proposed change fixes a defined error without introducing a regression on untouched data. |

Orders 1 and 2 are the highest-value next analytical work. They improve what the agent understands and how it ranks opportunities; another dashboard or additional role names alone would not close these gaps. A completed scheduled run is still necessary operational proof, but it does not replace analytical validation.

No live investment rule, risk limit, agent schedule or historical decision was changed by this review. No external framework was installed and no model performance ranking is claimed.
