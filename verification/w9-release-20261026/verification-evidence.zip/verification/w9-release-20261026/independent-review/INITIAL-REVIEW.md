# W9 initial independent review — 26 October 2026

Reviewer: separate AI reviewer `/root/w9_release_reviewer`, authorized by Mohamed. This is independent of the implementation task allocation, not independent human validation. No production code, policy, collector or historical ledger changed by this review.

Scope: W9.1–W9.7 in `verification/independent-audit-20261024/REMEDIATION-PLAN.md`, frozen Phase 3 test plan, current workflow dispatcher/adapters/input bridge, v5 execution store, evaluation ledger, and W8 client service.

## Findings awaiting fixes and re-review

1. **High — registered v5 exposure is omitted from dispatcher inputs. [VERIFIED]** An isolated actual v5 store contained one HELD position and was registered through `registerClientLedger`. `readWorkflowInputs` returned empty positions and livePositions with no v5 exposure input. Planner minute obligations consequently have no path to that position. Remedy: read registered ledgers with semantic integrity validation, retain exact identity, monitor holdings and unresolved intents, and report unknown/unreadable ledgers as critical rather than zero. Identity ambiguity must not route a guessed ticker.
2. **High — failed report delivery leaves a run falsely active. [VERIFIED]** Injected unavailable checkpoint destination into `executeWorkflow` with zero jobs. It called the failing sink twice; database status remained running and finished_at null, although its stored report status said failed. Remedy: durable finalization independent of report sink; explicit failed-delivery incident, no claimed delivery, bounded sink behavior, safe fallback. Also inspect CLI error handling and report-directory creation after run start.
3. **High — user intervention attribution stops at the client card. [VERIFIED]** An actual `controlLedger(PAUSE)` appended the expected clientIntervention event, but `ledgerMetrics` emitted no intervention attribution. This permits an evaluation consumer to treat the changed path as policy-only. Remedy: quarantine/partition intervened ledgers in source-bound and comparison wrappers; preserve frozen engine history and expose descriptive metrics with intervention labels. Test canceled pending entries and paused held portfolios.
4. **Medium — canonical npm test excludes newer suites. [VERIFIED]** `package.json` test command omits v5-evaluation, v5-w7 and v5-client tests. Remedy: authoritative W9 release runner enumerates every required current suite and binds test command/results to source hashes without altering previously frozen execution-release files unnecessarily.
5. **High release-evidence requirement — final-minute reserve and CLI failure coverage. [INFERRED]** Current dispatcher allocates entire remaining runtime to a child and awaits checkpoint without its own timeout. A canceled adapter is not proof the final minute was reserved. Mandatory tests must exercise the actual production CLI, report-dir creation failures, input/planner failures and report-sink failure, including truthful finished status and preserved incomplete jobs.

Exact reproducible findings 1–3, source hashes and output: `initial-reproduction.json`; reproduction: `reproduce-initial.mjs`. All state in this directory is labeled isolated synthetic engineering evidence.

## Closure criteria challenged in the final review

- 1,000 generated cases use frozen seed 20261023, broad arithmetic/chronology/state variations and reproducible assertions; repeated copies of a single example are insufficient.
- Three actual-interface session-equivalent replays cover successful entry and exit, rejection, no fill, pending reconciliation and blocked exit, with source outage and real restart.
- Fault inventory maps every frozen mandatory case to evidence; missing mandatory cases stay BLOCKED.
- Restore proves SQLite consistency/counts/state hashes, forward schema compatibility and replay. Rollback preserves post-snapshot evidence/events and does not silently replace mutable stores with an older backup.
- Release manifest identifies exact code/config/dependency/runtime content and archived artifacts. Checks cannot merely compare a file with the same just-created hash value.
- Launch blockers W1 rights/rules, W3 data/actions, W8 actual human comprehension and two authorized actual-session shadow days remain explicit. Synthetic software correctness is not operational readiness, prospective performance or authorization.

Disposition: INITIAL REVIEW ONLY. W9 closure is withheld pending final implementation, test outputs, release manifest and independent re-review. No claim that the prospective pilot is ready.
