import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {workflowCommand} from '../../../app/workflow-agent.mjs';
const here=new URL('./',import.meta.url),root=fileURLToPath(new URL('cli-sink-'+Date.now()+'/',here));mkdirSync(join(root,'data/operations'),{recursive:true});writeFileSync(join(root,'data/operations/workflow-reports'),'Synthetic destination obstruction');let error=null;
try{await workflowCommand(['run','checkpoint'],root);}catch(e){error=e.message;}
const db=new DatabaseSync(join(root,'data/operations/workflow.sqlite'),{readOnly:true}),rows=db.prepare('SELECT id,status,started_at,finished_at,report FROM workflow_runs').all();db.close();
const evidence={reviewer:'/root/w9_release_reviewer',tag:'VERIFIED',scope:'Isolated actual production workflowCommand interface; no collector started',error,rows,defect:rows.some(r=>r.status==='running'&&!r.finished_at)};writeFileSync(new URL('cli-report-directory-reproduction.json',here),JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence,null,2));
