import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,writeFileSync,readFileSync} from 'node:fs';
import {join} from 'node:path';
import {createHash} from 'node:crypto';
import {openWorkflow,beginWorkflow} from '../../../app/workflow-store.mjs';
import {executeWorkflow} from '../../../app/workflow-runner.mjs';
import {readWorkflowInputs} from '../../../app/workflow-inputs.mjs';
import {openExecutionStore} from '../../../app/v5/execution-store.mjs';
import {executionFixture,acceptance,minuteFixture,prepareAt,acceptAt} from '../../../app/v5/execution-fixtures.mjs';
import {readEvaluationLedger,ledgerMetrics} from '../../../app/v5/evaluation-ledger.mjs';
import {registerClientLedger,controlLedger} from '../../../app/v5/client-service.mjs';
const here=new URL('./',import.meta.url),out=new URL('initial-reproduction.json',here),base=new URL('isolated-'+Date.now()+'/',here);mkdirSync(base,{recursive:true});
const root=decodeURIComponent(base.pathname).replace(/^\/(.:)/,'$1');
const evidence={reviewer:'Independent reviewer /root/w9_release_reviewer',scope:'SYNTHETIC ENGINEERING ONLY; no collectors or production data writes',at:new Date().toISOString(),sourceHashes:{},results:[]};
for(const file of ['app/workflow-runner.mjs','app/workflow-inputs.mjs','app/v5/evaluation-ledger.mjs','app/v5/client-service.mjs'])evidence.sourceHashes[file]=createHash('sha256').update(readFileSync(new URL('../../../'+file,here))).digest('hex');
const db=openWorkflow(join(root,'workflow.sqlite')),now=new Date('2026-10-25T06:40:00Z');const run=beginWorkflow(db,{workload:'independent-W9',plannedAt:now.toISOString(),deadlineMs:1000},now);let calls=0,error=null;
try{await executeWorkflow(db,run,{jobs:[],obligations:[],sourceGaps:[],minuteTargets:[]},{clock:()=>now,checkpoint:()=>{calls++;throw Error('Injected report destination unavailable');}});}catch(e){error=e.message;}
const row=db.prepare('SELECT status,finished_at,report FROM workflow_runs WHERE id=?').get(run.id);evidence.results.push({id:'REPORT-SINK',tag:'VERIFIED',checkpointCalls:calls,error,durableStatus:row.status,finishedAt:row.finished_at,reportStatus:JSON.parse(row.report).status,defect:row.status==='running'&&row.finished_at===null});db.close();
mkdirSync(join(root,'data'),{recursive:true});new DatabaseSync(join(root,'data/egx.sqlite')).close();
const f=executionFixture(),path=join(root,'test-ledger.sqlite'),store=openExecutionStore(path,f.config);let n=0;function append(type,data,at){return store.append({id:'review-'+(++n),type,data,at},{clock:new Date(at)});}
append('OPEN_DAY',{book:f.book},'2026-10-25T06:40:00Z');append('SET_PAUSE',{paused:false,reason:'Synthetic independent reproduction'},prepareAt);append('SUBMIT',acceptance(f,store.read()),acceptAt);const bar=minuteFixture(f.isin);append('MINUTE',{bar,book:f.book},bar.receivedAt);store.close();registerClientLedger(root,{id:'review-ledger',label:'Synthetic independent held position',path:'test-ledger.sqlite',allowControls:true});
const audit=readEvaluationLedger(path),inputs=readWorkflowInputs(root,new Date('2026-10-25T07:18:00Z'));evidence.results.push({id:'V5-OBLIGATION-BRIDGE',tag:'VERIFIED',registeredHeldPositions:Object.values(audit.state.positions).map(p=>({isin:p.isin,status:p.status})),plannerInputPositions:inputs.positions,plannerLivePositions:inputs.livePositions,plannerInputKeys:Object.keys(inputs),defect:Object.keys(audit.state.positions).length>0&&!inputs.positions.length&&!inputs.livePositions.length&&!inputs.v5Positions?.length});
controlLedger(path,{kind:'PAUSE',actor:'Independent reviewer',reason:'Synthetic intervention test',expectedStateHash:audit.stateHash},new Date('2026-10-25T07:18:00Z'));const changed=readEvaluationLedger(path),metrics=ledgerMetrics(changed,{at:'2026-10-25T07:18:00Z'});evidence.results.push({id:'INTERVENTION-ATTRIBUTION',tag:'VERIFIED',interventionEvents:changed.events.filter(e=>e.data.clientIntervention).length,metricsKeys:Object.keys(metrics),metricsScope:metrics.scope,hasInterventionAttribution:JSON.stringify(metrics).includes('USER_INTERVENED'),defect:!JSON.stringify(metrics).includes('USER_INTERVENED')});
writeFileSync(out,JSON.stringify(evidence,null,2)+'\n');console.log(JSON.stringify(evidence.results,null,2));
