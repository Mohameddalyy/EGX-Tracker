from pathlib import Path
import hashlib,json,sqlite3,zipfile,sys,datetime
here=Path(__file__).resolve().parent
root=here.parents[2]
backup=root/'data/backups/remediation-batch1-20261024-verified'
manifest=json.loads((backup/'manifest.json').read_text(encoding='utf-8-sig'))
restore=Path('\\\\?\\'+str((here/'baseline-restored').resolve()))
quote=lambda x:'"'+x.replace('"','""')+'"'
def digest(db,table,columns):
    h=hashlib.sha256();count=0
    for row in db.execute('SELECT '+','.join(map(quote,columns))+' FROM '+quote(table)+' ORDER BY rowid'):
        h.update(json.dumps(row,ensure_ascii=False,separators=(',',':'),default=lambda b:{'blobHex':b.hex()}).encode());h.update(b'\n');count+=1
    return {'count':count,'sha256':h.hexdigest(),'columns':columns}
def snapshot():
    result={}
    for d in manifest['databases']:
        with sqlite3.connect(((here/'baseline-restored')/d['path']).as_uri()+'?mode=ro',uri=True) as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            result[d['path']]={t:digest(db,t,[c[1] for c in db.execute('PRAGMA table_info('+quote(t)+')')]) for t in d['counts']}
    return result
if len(sys.argv)==1:
    restore.mkdir(exist_ok=True,parents=True)
    with zipfile.ZipFile(backup/'baseline.zip') as archive:
        entries={e['path']:e for e in manifest['entries']}
        assert len(archive.namelist())==len(entries)
        for name in archive.namelist():
            assert name in entries and not Path(name).is_absolute() and '..' not in Path(name).parts
            dest=restore/name;dest.parent.mkdir(parents=True,exist_ok=True)
            body=archive.read(name);assert hashlib.sha256(body).hexdigest()==entries[name]['sha256'],name
            dest.write_bytes(body);assert hashlib.sha256(dest.read_bytes()).hexdigest()==entries[name]['sha256']
    before=snapshot()
    for d in manifest['databases']:
        for t,c in d['counts'].items():assert before[d['path']][t]['count']==c
    (here/'restore-before.json').write_text(json.dumps(before,indent=2))
    print(json.dumps({'restoredFiles':len(entries),'verifiedBytes':sum(e['bytes'] for e in entries.values()),'databases':len(before),'status':'RESTORED_ALL_MANIFEST_HASHES_AND_COUNTS'}),flush=True)
else:
    before=json.loads((here/'restore-before.json').read_text());checks=[]
    for path,tables in before.items():
        with sqlite3.connect(((here/'baseline-restored')/path).as_uri()+'?mode=ro',uri=True) as db:
            assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
            for table,expected in tables.items():
                got=digest(db,table,expected['columns']);assert got==expected,(path,table)
                checks.append({'database':path,'table':table,'count':got['count'],'oldColumnsUnchanged':True,'sha256':got['sha256']})
    result={'reviewer':'Independent /root/w9_release_reviewer','tag':'VERIFIED','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'archiveSha256':hashlib.sha256((backup/'baseline.zip').read_bytes()).hexdigest(),'manifestSha256':hashlib.sha256((backup/'manifest.json').read_bytes()).hexdigest(),'restoredFiles':len(manifest['entries']),'allArchivedBytesVerified':True,'oldTableContentChecks':checks,'scope':'Isolated baseline restoration and production schema initializer migration only; not yet rollback of newer evidence, not atomic cross-database snapshot','status':'PASS'}
    (here/'baseline-restore-migration-result.json').write_text(json.dumps(result,indent=2));print(json.dumps({'status':result['status'],'oldTablesVerified':len(checks),'oldRowsVerified':sum(c['count'] for c in checks)}))

