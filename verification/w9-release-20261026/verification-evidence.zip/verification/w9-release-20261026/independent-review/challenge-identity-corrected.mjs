import {v5Obligations} from '../../../app/workflow-v5.mjs';
import {readdirSync,readFileSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
const dir=fileURLToPath(new URL('./',import.meta.url)),roots=readdirSync(dir).filter(x=>x.startsWith('isolated-')).sort(),root=dir+'/'+roots.at(-1),isin='EG0000000001';
const cases={missing:[],unique:[{ticker:'TEST',metadata:{symbolInfo:{isin},symbolExt:{isin}}}],ambiguous:[{ticker:'TEST',metadata:{symbolInfo:{isin}}},{ticker:'OTHER',metadata:{symbolInfo:{isin}}}],conflicting:[{ticker:'TEST',metadata:{symbolInfo:{isin},symbolExt:{isin:'EG0000000002'}}}]};
const results=Object.entries(cases).map(([name,stocks])=>{const r=v5Obligations(root,stocks);return {name,status:r.status,positions:r.positions.map(p=>({isin:p.isin,ticker:p.ticker})),errors:r.errors,defect:name==='conflicting'&&r.status==='VERIFIED'};});
writeFileSync(new URL('identity-challenge-corrected.json',import.meta.url),JSON.stringify({reviewer:'/root/w9_release_reviewer',tag:'VERIFIED',results},null,2));console.log(JSON.stringify(results,null,2));

