import {verifyMinuteReceipt} from '../../../app/workflow-minute-receipt.mjs';
import {mkdirSync,writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
const here=fileURLToPath(new URL('./',import.meta.url)),root=join(here,'receipt-challenge-'+Date.now()),dir=join(root,'data/operations/minute-observations');mkdirSync(dir,{recursive:true});const now=new Date(),capturedAt=now.toISOString(),time=Math.floor(+now/60000)*60-60,bar={time,open:70,high:71,low:69,close:70,volume:1000};const base={ticker:'TEST',symbol:'EGX:TEST',resolution:'1',chartType:1,timezone:'Africa/Cairo',currency:'EGP',exchange:'EGX',loading:false,delaySeconds:0,capturedAt,bars:[bar]};const inputs={valid:base,duplicate_conflicting:{...base,bars:[bar,{...bar,close:71}]},symbol_exchange_conflict:{...base,symbol:'NASDAQ:TEST'}};const cases=[];
for(const [name,s] of Object.entries(inputs)){const path=join(dir,name+'.json');writeFileSync(path,JSON.stringify({restored:true,errors:[],stocks:[s]}));const r=verifyMinuteReceipt(root,{status:'succeeded',observationOnly:true,tradeAuthorization:false,restored:true,accepted:null,tickers:['TEST'],path},['TEST'],new Date(+now-1000).toISOString());cases.push({name,status:r.status,incident:r.incident??null,message:r.message??null,quality:r.observationQuality??null,defect:name!=='valid'&&r.status==='succeeded'});}
writeFileSync(new URL('minute-receipt-challenge-corrected.json',import.meta.url),JSON.stringify({reviewer:'/root/w9_release_reviewer',tag:'VERIFIED',cases},null,2));console.log(JSON.stringify(cases,null,2));

